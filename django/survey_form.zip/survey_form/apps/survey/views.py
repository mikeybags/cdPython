from django.shortcuts import render, redirect

# Create your views here.
def index(request):
    locations = {'Chicago': 'Chicago',
                 'Dallas' : 'Dallas',
                 'San Francisco': 'San Francisco',
                 'Seattle': 'Seattle'}
    languages = [{'language': 'Javascript'},
                 {'language': 'Ruby'},
                 {'language': 'Python'}]
    return render(request, 'survey/index.html', locations, languages)
